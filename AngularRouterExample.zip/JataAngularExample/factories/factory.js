app.factory('loginFactory', ['$http', function($http) {
    var c;
    var urlBase = 'json/';
    var url= 'login.json';
    var url2= 'details.json';
    var loginFactory = {};
    loginFactory.login = function () {
        return $http.get(urlBase+url);
    };
    loginFactory.add= function (a,b) {
    	c=a+b;
    	return c;
    };
    loginFactory.empDetails = function () {
        return $http.get(urlBase+url2);
    };
    return loginFactory;
}]);