app.controller('HomeController', function($scope,loginFactory) {
  alert("in ");
var dataArray=[];
  	loginFactory.empDetails()
  	 .success(function (data) {
  	 	console.log((data.length));
  	 	for(i=0;i<data.length;i++)
  	 	{
  	 		dataArray[i]=data[i].Name;
  	 	}
  	 	console.log(dataArray);
  	 	$scope.dataArray=dataArray;
  	 	console.log($scope.dataArray);
  	 });
});