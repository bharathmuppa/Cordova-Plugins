app.controller('LoginController',function($scope,loginFactory) {
  
  $scope.section='templates/Login.html';
  $scope.login = function (username, password,dob) {
  	loginFactory.login()
            .success(function (data) {
                //$scope.username = data;
                for(var i=0;i<data.length;i++){
                if ( username === data[i].username && password === data[i].password && dob=== data[i].dob) {
    	alert("hi");
        user = data[i].username;
       $scope.section='templates/Home.html';
      
    } else {
    	alert("error");
        $scope.loginError = "Invalid username/password combination";
    };
    }
            })
            .error(function (error) {
                $scope.status = 'Unable to login: ' + error.message;
            });
    
  };

});