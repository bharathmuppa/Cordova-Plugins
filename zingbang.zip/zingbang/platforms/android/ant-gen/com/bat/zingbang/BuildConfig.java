/** Automatically generated file. DO NOT MODIFY */
package com.bat.zingbang;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}