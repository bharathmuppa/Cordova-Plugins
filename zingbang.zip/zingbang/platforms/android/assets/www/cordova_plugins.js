cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/com.blessanmathew.smsreceiver/www/sms-receiver.js",
        "id": "com.blessanmathew.smsreceiver.SmsReceiver",
        "clobbers": [
            "window.smsreceiver"
        ]
    },
    {
        "file": "plugins/info.asankan.phonegap.smsplugin/www/smsplugin.js",
        "id": "info.asankan.phonegap.smsplugin.smsplugin",
        "clobbers": [
            "smsplugin"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "com.blessanmathew.smsreceiver": "0.1.0",
    "info.asankan.phonegap.smsplugin": "0.2.0"
}
// BOTTOM OF METADATA
});