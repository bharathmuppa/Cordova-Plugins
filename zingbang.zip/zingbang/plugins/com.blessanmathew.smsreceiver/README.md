PhonegapSmsReceiver
===================

A phonegap 3.0 plugin for reading incoming SMS messages.
